import React, { useEffect } from 'react';
import { View, Text } from 'react-native';
import axios from 'axios';


const App = () => {
  useEffect(() => {
    axios.get('http://192.168.1.67:3000/rent')
      .then(response => {
        console.log(response.data);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);

  return (
    <View>
      <Text>Holaa</Text>
    </View>
  );
};

export default App;
