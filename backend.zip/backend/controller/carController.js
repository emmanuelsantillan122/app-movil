const Car = require('../models/car');

exports.rentCar = async (req, res) => {
  try {
    const { carId } = req.body;
    const car = await Car.findById(carId);

    if (!car) {
      return res.status(404).send('Carro no encontrado');
    }

    if (car.isRented) {
      return res.status(400).send('El carro ya está rentado');
    }

    car.isRented = true;
    await car.save();

    res.status(200).send('Carro rentado con éxito');
  } catch (error) {
    res.status(500).send('Error al rentar el carro');
  }
};
